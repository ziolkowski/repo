﻿////Napisać program, który pobiera dwa argumenty z linii poleceń,
////ciągi znaków. Program ma sprawdzać czy drugi ciąg znaków jest podciągiem
////pierwszego(nie wolno używać substr, substring ani innej funkcji
////standardowej, w tym również bibliotek wyrażeń regularnych). Jeden
////warunek: każde wystąpienie * w drugim ciągu oznacza dopasowanie do zera
////lub więcej znaków pierwszego ciągu.Jeśli wejściem do programu były
////ciągi abcd oraz a*c, wtedy drugi ciąg liczy się jako podciąg pierwszego.
////Dodatkowa funkcjonalność to zezwolenie na traktowanie gwiazdki jako
////normalny znak jeśli jest poprzedzona znakiem \, natomiast znak \ jest
////traktowany normalnie oprócz sytuacji, gdy poprzedza gwiazdkę.

namespace SubstringCheck
{
    using System;

    public class Program
    {
        private static string firstLine = string.Empty;
        private static string secondLine = string.Empty;
        private static char[] firstArray;
        private static char[] secondArray;
        private static bool result;
        private static int asterisks = 0;

        public static void Main(string[] args)
        {
            Console.WriteLine("Podaj pierwszy ciag:");
            firstLine = Console.ReadLine();
            firstArray = firstLine.ToCharArray();
            Console.WriteLine("Podaj drugi ciag:");
            secondLine = Console.ReadLine();
            secondArray = secondLine.ToCharArray();
            if (firstLine.Length >= secondLine.Length)
            {
                result = Check(firstArray, secondArray);
            }

            Console.WriteLine("---");
            if (result)
            {
                Console.WriteLine("Drugi ciag jest podciagiem pierwszego");
            }
            else
            {
                Console.WriteLine("Drugi ciag NIE jest podciagiem pierwszego");
            }

            Console.Read();
        }

        private static bool Check(char[] first, char[] second)
        {
            int row = 0;
            int doubleSigns = 0;
            for (int i = 0; i < second.Length; i++)
            {
                for (int j = 0; j < first.Length; j++)
                {
                    bool flag = false;

                    ////asterisk
                    if (second[i] == '*')
                    {
                        if (i > 0)
                        {
                            ////'\' sign -> treating asterisk as normal sign
                            if (second[i - 1] == 92)
                            {
                                flag = true;
                                doubleSigns++;
                            }
                        }

                        if (flag == false)
                        {
                            if (row == second.Length - 1 - asterisks)
                            {
                                return true;
                            }

                            asterisks++;
                            ////finding first non-aterisk char after asterisk
                            for (int k = i + 1; k < second.Length; k++)
                            {
                                if (second[k] != '*')
                                {
                                    i = k;
                                    break;
                                }
                                else
                                {
                                    asterisks++;
                                }
                            }
                            ////end of line B check
                            if (row == second.Length - asterisks)
                            {
                                return true;
                            }

                            for (int l = j; l < first.Length; l++)
                            {
                                if (second[i] == first[l])
                                {
                                    j = l;
                                    break;
                                }
                            }
                        }
                    }
                    ////treating '\' and next asterisk as one char
                    if (second[i] == 92)
                    {
                        if (second.Length > i + 1)
                        {
                            if (second[i + 1] == '*')
                            {
                                i++;
                                j--;
                                continue;
                            }
                        }
                    }

                    if (second[i] == first[j] || (second[i] == '*' && first[j] == '*' && flag == true))
                    {
                        row++;
                        if (i > 0 && row < 1)
                        {
                            return false;
                        }

                        if (i <= first.Length - 2)
                        {
                            i++;
                        }

                        if (row == second.Length - asterisks - doubleSigns)
                        {
                            return true;
                        }
                    }
                    else
                    {
                        row = 0;
                        ////    end of line B check
                        if (second.Length == i + 1)
                        {
                            return false;
                        }
                    }
                }
            }

            return false;
        }
    }
}
