﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SubstringCheck
{
    class Program
    {
        static string firstLine = "";
        static string secondLine = "";
        static char[] firstArray;
        static char[] secondArray;
        static bool result;
        static int asterisks = 0;

        private static bool Check(char[] First, char[] Second)
        {
            int row = 0;
            int doubleSigns = 0;
            for (int i = 0; i < Second.Length; i++)
            {
                for (int j = 0; j < First.Length; j++)
                {
                    bool flag = false;

                    //asterisk
                    if (Second[i] == '*')
                    {
                        if (i > 0)
                        {
                            if (Second[i - 1] == 92)//    '\' sign -> treating asterisk as normal sign
                            {
                                flag = true;
                                doubleSigns++;
                            }
                        }

                        if (flag == false) 
                        {
                            if (row == Second.Length - 1 - asterisks)
                            {
                                //result = true;
                                return true; ;
                            }
                            asterisks++;
                            for (int k = i + 1; k < Second.Length; k++)//finding first non-aterisk char after asterisk
                            {
                                if (Second[k] != '*')
                                {
                                    i = k;
                                    break;
                                }
                                else
                                {
                                    asterisks++;
                                }
                            }
                            if (row == Second.Length - asterisks) // end of line B check
                            {
                                return true;
                            }
                            for (int l = j; l < First.Length; l++)
                            {
                                if (Second[i] == First[l])
                                {
                                    j = l;
                                    break;
                                }
                            }
                        }
                    }
                    //treating '\' and next asterisk as one char
                    if (Second[i] == 92)
                    {
                        if(Second.Length > i + 1)
                        {
                            if(Second[i+1] == '*')
                            {
                                i++;
                                j--;
                                continue;
                            }
                        }
                    }

                    //
                    if (Second[i] == First[j] || (Second[i] == '*' && First[j] == '*' && flag == true))
                    {
                        row++;
                        if (i > 0 && row < 1)
                        {
                            return false;
                        }
                        if (i <= First.Length - 2)
                        {
                            i++;
                        }
                        if (row == Second.Length - asterisks - doubleSigns)
                        {
                            return true;
                        }
                    }
                    else
                    {
                        row = 0;
                        if(Second.Length == i + 1)//end of line B check
                        {
                            return false;
                        }
                    }
                }
            }
            return false;
        }

        static void Main(string[] args)
        {
            Console.WriteLine("Podaj pierwszy ciag:");
            firstLine = Console.ReadLine();
            firstArray = firstLine.ToCharArray();
            Console.WriteLine("Podaj drugi ciag:");
            secondLine = Console.ReadLine();
            secondArray = secondLine.ToCharArray();
            if (firstLine.Length >= secondLine.Length)
            {
                result = Check(firstArray, secondArray);
            }
            Console.WriteLine("---");
            if (result)
            {
                Console.WriteLine("Drugi ciag jest podciagiem pierwszego");
            }
            else
            {
                Console.WriteLine("Drugi ciag NIE jest podciagiem pierwszego");
            }
            Console.Read();//
        }
    }
}
