﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SubstringCheck
{
    class Program
    {
        static string a = "";
        static string b = "";
        static char[] aa;
        static char[] bb;
        static bool result;
        static int asterisks = 0;

        private static void Check(char[] A, char[] B)
        {
            int row = 0;
            int doubleSigns = 0;
            for (int i = 0; i < B.Length; i++)
            {
                for (int j = 0; j < A.Length; j++)
                {
                    bool flag = false;

                    //asterisk
                    if (B[i] == '*')
                    {
                        if (i > 0)
                        {
                            if (B[i - 1] == 92)//    '\' sign -> treating asterisk as normal sign
                            {
                                flag = true;
                                doubleSigns++;
                            }
                        }

                        if (flag == false) 
                        {
                            if (row == B.Length - 1 - asterisks)
                            {
                                result = true;
                                return;
                            }
                            asterisks++;
                            for (int k = i + 1; k < B.Length; k++)//finding first non-aterisk char after asterisk
                            {
                                if (B[k] != '*')
                                {
                                    i = k;
                                    break;
                                }
                                else
                                {
                                    asterisks++;
                                }
                            }
                            if (row == B.Length - asterisks) // end of line B check
                            {
                                result = true;
                                return;
                            }
                            for (int l = j; l < A.Length; l++)
                            {
                                if (B[i] == A[l])
                                {
                                    j = l;
                                    break;
                                }
                            }
                        }
                    }
                    //treating '\' and next asterisk as one char
                    if (B[i] == 92)
                    {
                        if(B.Length > i + 1)
                        {
                            if(B[i+1] == '*')
                            {
                                i++;
                                j--;
                                continue;
                            }
                        }
                    }

                    //
                    if (B[i] == A[j] || (B[i] == '*' && A[j] == '*' && flag == true))
                    {
                        row++;
                        if (i > 0 && row < 1)
                        {
                            return;
                        }
                        if (i <= A.Length - 2)
                        {
                            i++;
                        }
                        if (row == B.Length - asterisks - doubleSigns)
                        {
                            result = true;
                            return;
                        }
                    }
                    else
                    {
                        row = 0;
                        if(B.Length == i + 1)//end of line B check
                        {
                            return;
                        }
                    }
                }
            }
        }

        static void Main(string[] args)
        {
            result = false;
            Console.WriteLine("Podaj pierwszy ciag:");
            a = Console.ReadLine();
            aa = a.ToCharArray();
            Console.WriteLine("Podaj drugi ciag:");
            b = Console.ReadLine();
            bb = b.ToCharArray();
            if (a.Length >= b.Length)
            {
                Check(aa, bb);
            }
            Console.WriteLine("---");
            if (result)
            {
                Console.WriteLine("Drugi ciag jest podciagiem pierwszego");
            }
            else
            {
                Console.WriteLine("Drugi ciag NIE jest podciagiem pierwszego");
            }
            Console.Read();//
        }
    }
}
