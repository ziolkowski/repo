﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EncryptionTask
{
    class Program
    {
        static string encryption(string s)
        {
            string res = string.Empty;
            s = s.Replace(" ", string.Empty);
            int L = s.Length;
            //Length condition
            if (L > 81)
            {
                return "\n--> Message is too long <--\n";
            }
            double sq = Math.Sqrt(L);
            int rows = Convert.ToInt32(Math.Floor(sq));
            int columns = Convert.ToInt32(Math.Ceiling(sq));
            //Minimum dimensions condition
            if (rows * columns < L)
            {
                rows++;
            }
            int moduloParam = L % columns;
            int cnt = 0;
            int limiter = 0;
            char[] charArr = s.ToCharArray();
            for (int i = 0; i < columns; i++)
            {
                for (int j = 0; j < rows - limiter; j++)
                {
                    if (L - moduloParam <= cnt + 1)
                    {
                        limiter = 1;
                    }
                    res += charArr[j * columns + i];
                    cnt++;
                }
                res += " ";
            }
            //Removing last space
            res = res.Remove(res.Length - 1);
            return res;
        }

        static void Main(String[] args)
        {
            string s = Console.ReadLine();
            string result = encryption(s);
            Console.WriteLine("Result:\n" + result);
        }
    }
}
